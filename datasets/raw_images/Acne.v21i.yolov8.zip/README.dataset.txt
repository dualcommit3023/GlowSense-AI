# Acne > 2022-01-31 9:32pm
https://universe.roboflow.com/kritsakorn/acne-kbm0q

Provided by a Roboflow user
License: undefined

