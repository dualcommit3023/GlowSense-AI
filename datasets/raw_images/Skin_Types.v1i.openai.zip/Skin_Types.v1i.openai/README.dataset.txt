# Skin_Types > 2025-06-21 3:43am
https://universe.roboflow.com/trial-ylel8/skin_types-xh3ug-kqml3

Provided by a Roboflow user
License: CC BY 4.0

